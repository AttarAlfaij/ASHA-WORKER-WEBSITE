from flask import Flask, render_template, request, redirect, url_for, session, make_response, send_file, g
import io
import csv
import json
import os
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# --- Configuration ---
app = Flask(__name__)
app.secret_key = 'f2a96c2ff15682ccc1007b327991d7ca5cf7e6371278760bf894d22c25dd21fb' 

# --- Language Support ---
SUPPORTED_LANGUAGES = ['english', 'hindi', 'marathi', 'punjabi', 'bengali']
DEFAULT_LANGUAGE = 'english'

# Fallback translations in case files are missing
FALLBACK_TRANSLATIONS = {
    'app_name': 'ASHA EHR',
    'welcome': 'Welcome',
    'login': 'Sign In',
    'logout': 'Logout',
    'dashboard': 'Dashboard',
    'patients': 'Patients',
    'reminders': 'Reminders',
    'reports': 'Reports',
    'profile': 'Profile',
    'about': 'About',
    'contact': 'Contact Support',
    'language': 'Language',
    'english': 'English',
    'hindi': 'Hindi',
    'marathi': 'Marathi',
    'punjabi': 'Punjabi',
    'bengali': 'Bengali',
    'hello': 'Hello, %s',
    'total_patients': 'Total Patients',
    'today_visits': "Today's Visits",
    'pending_reminders': 'Pending Reminders',
    'completed_tasks': 'Completed Tasks',
    'quick_actions': 'Quick Actions',
    'register_patient': 'Register Patient',
    'record_visit': 'Record Visit',
    'scan_qr': 'Scan QR Code',
    'voice_input': 'Voice Input',
    'ambulance_info': 'Ambulance Info',
    'upcoming_reminders': 'Upcoming Reminders',
    'search_patients': 'Search patients...',
    'personal_info': 'Personal Information',
    'view_details': 'View your details',
    'sync_status': 'Sync Status',
    'privacy_security': 'Privacy & Security',
    'help_support': 'Help & Support',
    'version': 'Version',
    'description': 'Description',
    'patient_actions': 'Patient Actions',
    'call': 'Call',
    'done': 'Done',
    'ambulance_details': 'Ambulance Details',
    'ambulance_number': 'Ambulance Number',
    'driver_name': 'Driver Name',
    'available_247': 'Available 24/7',
    'contact_emergency': 'Contact for Emergencies',
    'call_ambulance': 'Call Ambulance',
    'close': 'Close',
    'no_upcoming_reminders': 'No upcoming reminders',
    'manage_permissions': 'Manage permissions and settings',
    'faqs_contact': 'FAQs and contact details',
    'role': 'Role',
    'contact': 'Contact',
    'name': 'Name'
}

def load_translations(lang_code):
    """Load translations for the given language code"""
    try:
        file_path = f'translations/{lang_code}.json'
        if not os.path.exists(file_path):
            print(f"Translation file not found: {file_path}")
            return FALLBACK_TRANSLATIONS
            
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            if not content:
                print(f"Translation file is empty: {file_path}")
                return FALLBACK_TRANSLATIONS
                
            translations = json.loads(content)
            print(f"Successfully loaded translations for: {lang_code}")
            return translations
            
    except json.JSONDecodeError as e:
        print(f"JSON decode error for {lang_code}: {e}")
        return FALLBACK_TRANSLATIONS
    except Exception as e:
        print(f"Error loading translations for {lang_code}: {e}")
        return FALLBACK_TRANSLATIONS

def get_current_language():
    """Get current language from session or return default"""
    return session.get('language', DEFAULT_LANGUAGE)

def gettext(key, *args):
    """Translation function similar to Flask-Babel"""
    lang_code = get_current_language()
    translations = load_translations(lang_code)
    translation = translations.get(key, FALLBACK_TRANSLATIONS.get(key, key))
    
    # Handle string formatting with arguments
    if args:
        try:
            return translation % args
        except:
            return translation
    return translation

# Context processor to make variables available to all templates
@app.context_processor
def inject_global_variables():
    return {
        'gettext': gettext,
        'current_language': get_current_language(),  # Call the function here
        'supported_languages': SUPPORTED_LANGUAGES
    }

# --- Mock Data Structures ---
MOCK_USERS = {
    'demo': {'password': 'demo123', 'role': 'ASHA Worker', 'name': 'Priya Sharma'},
    'phc_1': {'password': 'phc123', 'role': 'PHC Supervisor', 'name': 'Dr. Rohan Mehra'}, 
}

PATIENTS = [
    {'id': 101, 'name': 'Savita Devi', 'age': '35', 'gender': 'F', 'contact': '9876543210', 'status': 'ANC Due'},
    {'id': 102, 'name': 'Ramesh Kumar', 'age': '52', 'gender': 'M', 'contact': '8765432109', 'status': 'Diabetic'},
    {'id': 103, 'name': 'Baby Girl', 'age': '0', 'gender': 'F', 'contact': '9988776655', 'status': 'Newborn'},
]
NEXT_PATIENT_ID = 104

# --- Utility Functions ---
def requires_auth(f):
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    decorated.__name__ = f.__name__
    return decorated

def safe_int(value, default=0):
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

# --- Routes ---
@app.route('/')
def index():
    if 'user_id' in session:
        if session.get('user_role') == 'PHC Supervisor':
            return redirect(url_for('phc_dashboard'))
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    user_id = request.form.get('user_id')
    password = request.form.get('password')
    user_data = MOCK_USERS.get(user_id)
    if user_data and user_data['password'] == password:
        session['user_id'] = user_id
        session['user_name'] = user_data['name']
        session['user_role'] = user_data['role']
        # Set default language if not set
        if 'language' not in session:
            session['language'] = DEFAULT_LANGUAGE
        if user_data['role'] == 'PHC Supervisor':
            return redirect(url_for('phc_dashboard'))
        return redirect(url_for('dashboard'))
    return render_template('login.html', error='Invalid User ID or Password')

@app.route('/logout')
@requires_auth
def logout():
    session.clear()
    return redirect(url_for('index'))

# Language switching route
@app.route('/set_language/<lang_code>')
@requires_auth
def set_language(lang_code):
    if lang_code in SUPPORTED_LANGUAGES:
        session['language'] = lang_code
        print(f"Language set to: {lang_code}")
    return redirect(request.referrer or url_for('dashboard'))

@app.route('/dashboard')
@requires_auth
def dashboard():
    if session.get('user_role') == 'PHC Supervisor':
        return redirect(url_for('phc_dashboard'))
    context = {
        'name': session['user_name'], 
        'role': session['user_role'],
        'total_patients': len(PATIENTS),
        'today_visits': 3,
        'pending_reminders': 5,
        'completed_tasks': 12,
    }
    return render_template('dashboard.html', **context)

@app.route('/phc/dashboard')
@requires_auth
def phc_dashboard():
    if session.get('user_role') != 'PHC Supervisor':
        return redirect(url_for('dashboard'))
    stats = {
        'total_asha': 5,
        'patients_in_sector': len(PATIENTS),
        'anc_due_this_week': len([p for p in PATIENTS if p.get('status') == 'ANC Due']),
        'unresolved_cases': 2, 
    }
    return render_template('phc_dashboard.html', stats=stats, name=session['user_name'])

@app.route('/patients')
@requires_auth
def patients():
    return render_template('patients.html', patients=PATIENTS)

# @app.route('/patients/register', methods=['GET', 'POST'])
# @requires_auth
# def register_patient():
#     global NEXT_PATIENT_ID
#     if request.method == 'POST':
#         age = request.form.get('age', '').strip()
#         if not age.isdigit():
#             return render_template('register_patient.html', error="Please enter a valid age")
#         new_patient = {
#             'id': NEXT_PATIENT_ID,
#             'name': request.form.get('name'),
#             'age': age,
#             'gender': request.form.get('gender'),
#             'contact': request.form.get('contact'),
#             'status': 'New',
#         }
#         PATIENTS.append(new_patient)
#         NEXT_PATIENT_ID += 1
#         return redirect(url_for('patients'))
#     return render_template('register_patient.html')
@app.route('/patients/register', methods=['GET', 'POST'])
@requires_auth
def register_patient():
    global NEXT_PATIENT_ID
    if request.method == 'POST':
        age = request.form.get('age', '').strip()
        if not age.isdigit():
            return render_template('register_patient.html', error="Please enter a valid age")
        new_patient = {
            'id': NEXT_PATIENT_ID,
            'name': request.form.get('name'),
            'age': age,
            'gender': request.form.get('gender'),
            'contact': request.form.get('contact'),
            'address': request.form.get('address'),
            'status': request.form.get('status'),  # ✅ Now using the entered status
        }
        PATIENTS.append(new_patient)
        NEXT_PATIENT_ID += 1
        return redirect(url_for('patients'))
    return render_template('register_patient.html')


@app.route('/reminders')
@requires_auth
def reminders():
    if session.get('user_role') == 'PHC Supervisor':
        return redirect(url_for('phc_dashboard')) 
    return render_template('reminders.html')

@app.route('/reports')
@requires_auth
def reports():
    report_data = {
        'total_patients': len(PATIENTS),
        'male_patients': len([p for p in PATIENTS if p['gender'] == 'M']),
        'female_patients': len([p for p in PATIENTS if p['gender'] == 'F']),
        'children': len([p for p in PATIENTS if safe_int(p['age']) < 12]),
        'pregnant_women': 1,
        'anc_due': 1,
    }
    return render_template('reports.html', data=report_data)

@app.route('/profile')
@requires_auth
def profile():
    return render_template('profile.html', 
                           name=session['user_name'], 
                           role=session['user_role'],
                           sync_status='Connected')

@app.route('/contact')
@requires_auth
def contact():
    contact_info = {
        "support_email": "support@healthapp.org",
        "phone": "+91 9890141896",
        "address": "Primary Health Center, Solapur, India"
    }
    return render_template("contact.html", info=contact_info)

@app.route('/about')
@requires_auth
def about():
    app_info = {
        "name": "ASHA EHR App",
        "version": "1.0.0",
        "description": "This app is designed to help ASHA Workers and PHC Supervisors manage patient data and health records efficiently. You can view patient summaries, reports, and export data securely."
    }
    return render_template('about.html', app=app_info)

@app.route('/export_csv')
@requires_auth
def export_csv():
    data = [
        ['Type', 'Value'],
        ['Total Patients', str(len(PATIENTS))],
        ['Male Patients', str(len([p for p in PATIENTS if p['gender'] == 'M']))],
        ['Female Patients', str(len([p for p in PATIENTS if p['gender'] == 'F']))],
        ['Children (under 12)', str(len([p for p in PATIENTS if safe_int(p['age']) < 12]))],
        ['Pregnant Women', '1'],
        ['ANC Checkups Due', '1'],
    ]
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerows(data)
    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename=ASHA_Report.csv"
    output.headers["Content-type"] = "text/csv"
    return output

@app.route('/export_pdf')
@requires_auth
def export_pdf():
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter

    c.setFont("Helvetica-Bold", 18)
    c.drawString(50, height - 50, "ASHA Worker Report")
    
    c.setFont("Helvetica", 12)
    y = height - 100

    report_data = [
        ['Total Patients', len(PATIENTS)],
        ['Male Patients', len([p for p in PATIENTS if p['gender'] == 'M'])],
        ['Female Patients', len([p for p in PATIENTS if p['gender'] == 'F'])],
        ['Children (under 12)', len([p for p in PATIENTS if int(p['age']) < 12])],
        ['Pregnant Women', 1],
        ['ANC Checkups Due', 1],
    ]

    for item in report_data:
        c.drawString(50, y, f"{item[0]}: {item[1]}")
        y -= 20

    c.showPage()
    c.save()

    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name="ASHA_Report.pdf", mimetype='application/pdf')

# --- Run App ---
if __name__ == '__main__':
    # Create translations directory if it doesn't exist
    if not os.path.exists('translations'):
        os.makedirs('translations')
        print("Created translations directory")
    
    app.run(debug=True)